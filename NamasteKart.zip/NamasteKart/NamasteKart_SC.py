#NAMASTE KART PROJECT SOURCE CODE
#---------------------------------Anudyoti Deb

#1- importing all the required modules

import os
import csv
import shutil
import datetime 
from datetime import date
from datetime import datetime

#2- creates a variable with the name of the todays folder first

folder_name = str(date.today()).replace('-', '')
if os.path.exists(f'Incoming_Files/{folder_name}') == False: #to avoid any exceptions(safe mode)
    incoming_path = f'Incoming_Files/{folder_name}'
    os.makedirs(incoming_path)

#3- extract all the filenames & paths from the incoming file

file_path = [] #will contain list of all the file paths inside incoming folder.
for name in os.listdir(f'Incoming_Files/{folder_name}'): #extracting the filename from the path
    if name != '.ipynb_checkpoints': #issue with jupyter notebook
        file_path.append(f'Incoming_Files/{folder_name}/' + name)

#4- reading the product master table

with open('product_master.csv', 'r') as p:
    p_reader = csv.reader(p)
    p_header = []
    p_header = next(p_reader) # seperating header from the record
    p_rows = []
    for row in p_reader:
        p_rows.append(row) # seperating record from the header
    p_product_id = []  # extracting the product ids from record
    for i in p_rows:
        p_product_id.append(i[0])

#5- iterate through each file one by one inside the incoming folder

for path in file_path:
    with open(path,'r') as o:
        o_reader = csv.reader(o) # reading the orders table
        file_name = os.path.basename(path)
        o_header = [] 
        o_header = next(o_reader) # seperating header from the record
        o_rows = []
        for row in o_reader:
            o_rows.append(row) # seperating record from the header

    comment = []
    #checking all the conditions for the 1st row of the order table and then moving on to the next row till n rows.
    for row in o_rows: #this loop will continue untill all rows from the file are validated.
        err_msg = []
        
        # 1- product id should be present in product master table.
        if row[2] in p_product_id:
            pass
        else:
            err_msg += [f'product id {row[2]} is not present in product master table'] 
        
        # 2- total sales amount should be (product price from product master table * quantity)
        for i in p_rows:
            if (i[0]) == row[2]:#if IDs from both table are matching get the unit price * multiply
                if int(row[3]) * int(i[2]) == int(row[4]):
                    pass
                else:
                    err_msg += [f'total sales of {row[4]} is incorrect']
    
        # 3- the order date should not be in future
        if datetime.strptime(row[1],'%m-%d-%Y').date() <= date.today():
            pass
        else:
            err_msg += [f'order date {row[1]} is in future']
    
        # 4- any field should not be empty
        for item in row:
            if item != '':
                pass
            else:
                err_msg += [f'no value found in column {row.index(item)+1}']
    
        # 5- The orders should be from Mumbai or Bangalore only.
        if row[5].lower() in ['bangalore','mumbai']:
            pass
        else:
            err_msg += [f'order is from {row[5]} and not from Mumbai or Bangalore']
    
        #final condition 
        if err_msg == []:
            continue
        else:
            comment.append(row + err_msg)
        
    
    if err_msg == []:
        #path created for the day when a file is success
        if os.path.exists(f'Success_Files/{folder_name}') == False:
            success_path = f'Success_Files/{folder_name}'
            os.makedirs(success_path)
        # success order copy (goes into success folder)
        shutil.copyfile(f'Incoming_Files/{folder_name}/{file_name}',f'Success_Files/{folder_name}/success_{file_name}')
    else:
        #path created for the day when a file is rejected
        if os.path.exists(f'Rejected_Files/{folder_name}') == False:
            rejected_path = f'Rejected_Files/{folder_name}'
            os.makedirs(rejected_path)
        # rejected order copy (goes into rejected folder)
        shutil.copyfile(f'Incoming_Files/{folder_name}/{file_name}',f'Rejected_Files/{folder_name}/rejected_{file_name}')
        
        # creating an error file of the rejected file (goes into rejected folder)
        with open(f'Rejected_Files/{folder_name}/error_{file_name}', 'w', newline='') as efile:
            writer = csv.writer(efile)
            field = o_header + ['comment']
            writer.writerow(field)
            for i in comment:
                writer.writerow(i)

#6- counting incoming files

count_i=0
if os.path.exists(f'Incoming_Files/{folder_name}') == True:
    for i in os.listdir(f'Incoming_Files/{folder_name}'):
        if i != '.ipynb_checkpoints': #issue with jupyter notebook
            count_i += 1
#counting successful files
count_s=0
if os.path.exists(f'Success_Files/{folder_name}') == True:
    for s in os.listdir(f'Success_Files/{folder_name}'):
        if s != '.ipynb_checkpoints': #issue with jupyter notebook
            count_s += 1
#counting rejected files
count_r=0
if os.path.exists(f'Rejected_Files/{folder_name}') == True:
    for r in os.listdir(f'Rejected_Files/{folder_name}'):
        if r != '.ipynb_checkpoints': #issue with jupyter notebook
            count_r += 1
    count_r = count_r // 2


#7 - email attributes

email_sub = f'NamasteKart Order Validation Email for {folder_name}'
# email_to = 
# email_from = 
email_body = ("Total incoming files : " + str(count_i) + "\n" +
             "Total successful files : " + str(count_s) + "\n" +
             "Total rejected files : " + str(count_r))

#email alternative. email feature is not used in this source code due to privacy concern.
print(email_sub)
print()
print(email_body)

#------END OF PROGRAM-------(Anudyoti Deb)#

        
